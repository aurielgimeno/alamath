$(document).ready(function(){
	$("body").velocity({opacity:1},1000);
	gameStart();
	openWindow();
	changeCharElements();
});
