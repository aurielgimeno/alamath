	var quizArrayAddition = [{
		"id":"0",
		"q1":"1",
		"q2":"1",
		"question":"1 + 1 = ?",
		"choice1":"3",
		"choice2":"2",
		"choice3":"1",
		"correct":"2"
	},
	{
		"id":"1",
		"q1":"2",
		"q2":"2",
		"question":"2 + 2 = ?",
		"choice1":"4",
		"choice2":"2",
		"choice3":"5",
		"correct":"4"
	},
	{
		"id":"2",
		"q1":"2",
		"q2":"1",
		"question":"2 + 1 = ?",
		"choice1":"2",
		"choice2":"1",
		"choice3":"3",
		"correct":"3"
	},
	{
		
		"id":"3",
		"q1":"2",
		"q2":"3",
		"question":"2 + 3 = ?",
		"choice1":"3",
		"choice2":"4",
		"choice3":"5",
		"correct":"5"
	},
	{
		"id":"4",
		"q1":"3",
		"q2":"3",
		"question":"3 + 3 = ?",
		"choice1":"6",
		"choice2":"4",
		"choice3":"0",
		"correct":"6"
	},
	{
		"id":"5",
		"q1":"4",
		"q2":"2",
		"question":"4 + 2 = ?",
		"choice1":"4",
		"choice2":"2",
		"choice3":"6",
		"correct":"6"
	}
	]
	
	